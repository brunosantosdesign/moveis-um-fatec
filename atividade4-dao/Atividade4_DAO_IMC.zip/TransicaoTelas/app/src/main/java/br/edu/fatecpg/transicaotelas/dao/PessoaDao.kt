package br.edu.fatecpg.transicaotelas.dao

import br.edu.fatecpg.transicaotelas.model.Pessoa

class PessoaDao {
    companion object{
        private var pessoa: Pessoa? = null
    }

    fun cadastroContato(pessoa:Pessoa){
        Companion.pessoa = pessoa
    }
    fun exibirContato():Pessoa{
        return Companion.pessoa?:Pessoa()
    }
}