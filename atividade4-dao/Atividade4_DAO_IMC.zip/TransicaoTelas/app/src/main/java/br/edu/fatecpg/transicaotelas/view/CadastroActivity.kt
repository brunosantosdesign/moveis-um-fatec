package br.edu.fatecpg.transicaotelas.view

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.edu.fatecpg.transicaotelas.R
import br.edu.fatecpg.transicaotelas.dao.PessoaDao
import br.edu.fatecpg.transicaotelas.model.Pessoa
import com.google.android.material.floatingactionbutton.FloatingActionButton

class CadastroActivity : AppCompatActivity() {
    val dao = PessoaDao()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)
        //edt_nome,edt_whats,btn_salvar,fab_lista
        val edtNome = findViewById<EditText>(R.id.edt_peso)
        val edtWhats = findViewById<EditText>(R.id.edt_altura)
        val btnSalvar = findViewById<Button>(R.id.btn_salvar)
        val fabLista = findViewById<FloatingActionButton>(R.id.fab_lista)
        btnSalvar.setOnClickListener{
            val nome = edtNome.text.toString()
            val whats = edtWhats.text.toString()
            val pessoa = Pessoa(nome,whats)
            dao.cadastroContato(pessoa)
            Toast.makeText(this, "Cadastro Realizado com Sucesso", Toast.LENGTH_LONG).show()
            edtNome.text.clear()
            edtWhats.text.clear()
        }
        fabLista.setOnClickListener{
            val intent = Intent(this,ListaActivity::class.java)
            startActivity(intent)
        }
    }
}