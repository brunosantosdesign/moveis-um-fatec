package br.edu.fatecpg.transicaotelas.view

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import br.edu.fatecpg.transicaotelas.R
import br.edu.fatecpg.transicaotelas.dao.PessoaDao
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ListaActivity : AppCompatActivity() {
    val dao = PessoaDao()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista)

        // Referências aos TextViews e FloatingActionButton
        val txvPeso = findViewById<TextView>(R.id.txv_peso)
        val txvAltura = findViewById<TextView>(R.id.txv_altura)
        val txvImc = findViewById<TextView>(R.id.txv_imc)
        val txvClassificacao = findViewById<TextView>(R.id.txv_classificacao)
        val fabVolta = findViewById<FloatingActionButton>(R.id.fab_volta)

        // Obtém a pessoa do DAO
        val pessoa = dao.exibirContato()

        // Exibe o peso e a altura
        txvPeso.text = pessoa.peso
        txvAltura.text = pessoa.altura

        // Verifique se peso e altura não são nulos ou vazios
        if (!pessoa.peso.isNullOrEmpty() && !pessoa.altura.isNullOrEmpty()) {
            try {
                // Converte o peso e altura para Double e calcula o IMC
                val peso = pessoa.peso.toDouble()
                val altura = pessoa.altura.toDouble()

                // Certifique-se de que a altura está em metros
                val alturaEmMetros = if (altura > 10) altura / 100 else altura

                val imc = calcularImc(peso, alturaEmMetros)
                val classificacao = classificarImc(imc)

                // Exibe o IMC e a classificação
                txvImc.text = String.format("IMC: %.2f", imc)
                txvClassificacao.text = classificacao
            } catch (e: NumberFormatException) {
                // Tratamento de erro caso a conversão falhe
                txvImc.text = "Erro ao calcular IMC"
                txvClassificacao.text = "Valores inválidos"
            }
        } else {
            txvImc.text = "Peso ou altura inválidos"
            txvClassificacao.text = "Insira valores válidos"
        }

        // Ação para o botão flutuante
        fabVolta.setOnClickListener {
            finish()
        }
    }

    private fun calcularImc(peso: Double, altura: Double): Double {
        return peso / (altura * altura)
    }

    private fun classificarImc(imc: Double): String {
        return when {
            imc < 18.5 -> "Abaixo do peso"
            imc < 24.9 -> "Peso normal"
            imc < 29.9 -> "Sobrepeso"
            imc < 34.9 -> "Obesidade grau I"
            imc < 39.9 -> "Obesidade grau II"
            else -> "Obesidade grau III"
        }
    }
}
