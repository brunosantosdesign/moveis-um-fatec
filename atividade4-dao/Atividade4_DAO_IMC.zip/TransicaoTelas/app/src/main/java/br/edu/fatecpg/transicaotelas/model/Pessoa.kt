package br.edu.fatecpg.transicaotelas.model

data class Pessoa(
    val peso:String = "",
    val altura:String = ""
)
